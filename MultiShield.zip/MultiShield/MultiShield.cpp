#include "MultiShield.h"
#include <Servo.h>

Servo s1;
Servo s2;
Servo s3;
Servo s4;

_MultiShield MultiShield;

_MultiShield::_MultiShield(){
  s1.attach(SERVO_1);
  s2.attach(SERVO_2);
  s3.attach(SERVO_3);
  s4.attach(SERVO_4);
  pinMode(LED_1,OUTPUT);
  pinMode(LED_2,OUTPUT);
  pinMode(LED_3,OUTPUT);
  pinMode(LED_4,OUTPUT);
  pinMode(pinSirenka, OUTPUT);
  pinMode(pinLatch, OUTPUT);
  pinMode(pinClk, OUTPUT);
  pinMode(pinData, OUTPUT);
  ::noTone(pinSirenka);
}

byte _MultiShield::readButton(byte channel){
  return digitalRead(channel);
}

int _MultiShield::readTrimmer(){
  return analogRead(trimr);
}

void _MultiShield::tone(int frekvence,unsigned int delka){
  ::tone(pinSirenka,frekvence,delka);
}

void _MultiShield::tone(int frekvence){
  ::tone(pinSirenka,frekvence);
}

void _MultiShield::noTone(){
  ::noTone(pinSirenka);
}

void _MultiShield::writeLed(byte channel,byte napeti){
  napeti = !napeti;
  digitalWrite(channel,napeti);
}

void _MultiShield::writeSegment(byte segment, byte hodnota){
  digitalWrite(pinLatch,LOW);
  shiftOut(pinData, pinClk, MSBFIRST, mapaSegment[hodnota]);
  shiftOut(pinData, pinClk, MSBFIRST, mapaCisloSeg[segment] );
  digitalWrite(pinLatch,HIGH);
}

void _MultiShield::writeServo(byte channel,byte uhel){
  
}