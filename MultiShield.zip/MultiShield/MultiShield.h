#ifndef MultiShield_H
#define MultiShield_H
#include "Arduino.h"

const byte SWITCH_1 = A1;
const byte SWITCH_2 = A2;
const byte SWITCH_3 = A3;
const byte LED_1 = 13;
const byte LED_2 = 12;
const byte LED_3 = 11;
const byte LED_4 = 10;
const byte SERVO_1 = 5;
const byte SERVO_2 = 6;
const byte SERVO_3 = 9;
const byte SERVO_4 = A5;

class _MultiShield{
  public:
    _MultiShield();
    byte readButton(byte channel);
    int readTrimmer();
    void tone(int frekvence,unsigned int delka);
    void tone(int frekvence);
    void noTone();
    void writeLed(byte channel,byte napeti);
    void writeSegment(byte segment, byte hodnota);
    void writeServo(byte channel,byte uhel);

  private:
    #define pinLatch 4
    #define pinClk 7
    #define pinData 8
    #define trimr A0
    #define pinSirenka 3
    const byte mapaSegment[10] = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0X80,0X90};
    const byte mapaCisloSeg[4] = {0xF1,0xF2,0xF4,0xF8};
};

extern _MultiShield MultiShield;
#endif