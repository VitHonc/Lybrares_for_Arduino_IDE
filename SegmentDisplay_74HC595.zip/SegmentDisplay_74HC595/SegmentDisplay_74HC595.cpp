#include "Arduino.h"
#include "SegmentDisplay_74HC595.h"
SegmentDisplay_74HC595::SegmentDisplay_74HC595(){}

#define TYPE_ANODE '+'
#define TYPE_CATODE '-'

void SegmentDisplay_74HC595::begin(byte Clock, byte data, byte latch, char dTyp){
_zapojeni = false;
_type = dTyp;
_latchPin = latch;
_clockPin = Clock;
_dataPin = data;
pinMode(data,OUTPUT);
pinMode(Clock,OUTPUT);
pinMode(latch,OUTPUT);
}

void SegmentDisplay_74HC595::begin(byte anode, byte Clock, byte data, byte latch, char dTyp){
_zapojeni = true;
_anoda = anode;
_type = dTyp;
_latchPin = latch;
_clockPin = Clock;
_dataPin = data;
pinMode(data,OUTPUT);
pinMode(Clock,OUTPUT);
pinMode(latch,OUTPUT);
analogWrite(_anoda,255);
}

void SegmentDisplay_74HC595::write(int cislo,byte tecka){
if(_viditelnost == true){
if(_type == TYPE_ANODE){
    if(cislo == '.'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111110);
    _ZNAK = B11111110;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == '#' || cislo == ' '){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111111);
    _ZNAK = B11111111;
    digitalWrite(_latchPin,HIGH);
   }
  if(tecka == 1 || tecka == '1'){
    if(cislo == '_'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111100);
    _ZNAK = B11111100;
    digitalWrite(_latchPin,HIGH);
  }
    if(cislo == '-'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11101110);
    _ZNAK = B11101110;
    digitalWrite(_latchPin,HIGH);
  }
    if(cislo == 'A'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000010);
    _ZNAK = B00000010;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'b'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10100000);
    _ZNAK = B10100000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'C'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00110100);
    _ZNAK = B00110100;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'c'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11100100);
    _ZNAK = B11100100;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'd'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11000000);
    _ZNAK = B11000000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'E'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00100100);
    _ZNAK = B00100100;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'F'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00100110);
    _ZNAK = B00100110;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'H'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10000010);
    _ZNAK = B10000010;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'h'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10100010);
    _ZNAK = B10100010;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'I'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11011010);
    _ZNAK = B11011010;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'i'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111010);
    _ZNAK = B11111010;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'L'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10110100);
    _ZNAK = B10110100;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'n'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11100010);
    _ZNAK = B11100010;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'O'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00010000);
    _ZNAK = B00010000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'o'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11100000);
    _ZNAK = B11100000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'P'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000110);
    _ZNAK = B00000110;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'S'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00101000);
    _ZNAK = B00101000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'U'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10010000);
    _ZNAK = B10010000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'u'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11110000);
    _ZNAK = B11110000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'Y'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10001010);
    _ZNAK = B10001010;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'Z'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01000100);
    _ZNAK = B01000100;
    digitalWrite(_latchPin,HIGH);
  }

  if(cislo == 1 || cislo == '1'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11011010);
    _ZNAK = B11011010;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 2 || cislo == '2'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01000100);
    _ZNAK = B01000100;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 3 || cislo == '3'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01001000);
    _ZNAK = B01001000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 4 || cislo == '4'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10001010);
    _ZNAK = B10001010;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 5 || cislo == '5'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00101000);
    _ZNAK = B00101000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 6 || cislo == '6'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00100000);
    _ZNAK = B00100000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 7 || cislo == '7'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01011010);
    _ZNAK = B01011010;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 8 || cislo == '8'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000000);
    _ZNAK = B00000000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 9 || cislo == '9'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00001000);
    _ZNAK = B00001000;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 0 || cislo == '0'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00010000);
    _ZNAK = B00010000;
    digitalWrite(_latchPin,HIGH);
  }
}

  if(tecka == 0 || tecka == '0'){
    if(cislo == '-'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11101111);
    _ZNAK = B11101111;
    digitalWrite(_latchPin,HIGH);
  }
    if(cislo == '_'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111101);
    _ZNAK = B11111101;
    digitalWrite(_latchPin,HIGH);
  }
    if(cislo == 'A'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000011);
    _ZNAK = B00000011;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'b'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10100001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10100001;
  }
  if(cislo == 'C'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00110101);
    _ZNAK = B00110101;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'c'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11100101);
    _ZNAK = B11100101;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'd'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11000001);
    _ZNAK = B11000001;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == 'E'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00100101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00100101;
  }
  if(cislo == 'F'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00100111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00100111;
  }
  if(cislo == 'H'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10000011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10000011;
  }
  if(cislo == 'h'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10100011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10100011;
  }
  if(cislo == 'I'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11011011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11011011;
  }
  if(cislo == 'i'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11111011;
  }
  if(cislo == 'L'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10110101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10110101;
  }
  if(cislo == 'n'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11100011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11100011;
  }
  if(cislo == 'O'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00010001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00010001;
  }
  if(cislo == 'o'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11100001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11100001;
  }
  if(cislo == 'P'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00000111;
  }
  if(cislo == 'S'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00101001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00101001;
  }
  if(cislo == 'U'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10010001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10010001;
  }
  if(cislo == 'u'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11110001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11110001;
  }
  if(cislo == 'Y'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10001011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10001011;
  }
  if(cislo == 'Z'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01000101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01000101;
  }
  if(cislo == 1 || cislo == '1'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11011011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11011011;
  }
  if(cislo == 2 || cislo == '2'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01000101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01000101;
  }
  if(cislo == 3 || cislo == '3'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01001001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01001001;
  }
  if(cislo == 4 || cislo == '4'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10001011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10001011;
  }
  if(cislo == 5 || cislo == '5'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00101001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00101001;
  }
  if(cislo == 6 || cislo == '6'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00100001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00100001;
  }
  if(cislo == 7 || cislo == '7'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01011011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01011011;
  }
  if(cislo == 8 || cislo == '8'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00000001;
  }
  if(cislo == 9 || cislo == '9'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00001001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00001001;
  }
  if(cislo == 0 || cislo == '0'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00010001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00010001;
  }
}
}
if(_type == TYPE_CATODE){
    if(cislo == '.'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000001);
    _ZNAK = B00000001;
    digitalWrite(_latchPin,HIGH);
  }
  if(cislo == '#' || cislo == ' '){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000000);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00000000;
   }
  if(tecka == 1 || tecka == '1'){
    if(cislo == '-'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00010001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00010001;
  }
    if(cislo == '_'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00000011;
  }
    if(cislo == 'A'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11111101;
  }
  if(cislo == 'b'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01011111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01011111;
  }
  if(cislo == 'C'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11001011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11001011;
  }
  if(cislo == 'c'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00011011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00011011;
  }
  if(cislo == 'd'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00111111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00111111;
  }
  if(cislo == 'E'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11011011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11011011;
  }
  if(cislo == 'F'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11011001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11011001;
  }
  if(cislo == 'H'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01111101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01111101;
  }
  if(cislo == 'h'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01011101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01011101;
  }
  if(cislo == 'I'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00100101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00100101;
  }
  if(cislo == 'i'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00000101;
  }
  if(cislo == 'L'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01001011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01001011;
  }
  if(cislo == 'n'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00011101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00011101;
  }
  if(cislo == 'O'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11101111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11101111;
  }
  if(cislo == 'o'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00011111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00011111;
  }
  if(cislo == 'P'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111001);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11111001;
  }
  if(cislo == 'S'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11010111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11010111;
  }
  if(cislo == 'U'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01101111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01101111;
  }
  if(cislo == 'u'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00001111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00001111;
  }
  if(cislo == 'Y'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01110101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01110101;
  }
  if(cislo == 'Z'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10111011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10111011;
  }
  if(cislo == 1 || cislo == '1'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00100101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00100101;
  }
  if(cislo == 2 || cislo == '2'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10111011);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10111011;
  }
  if(cislo == 3 || cislo == '3'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10110111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10110111;
  }
  if(cislo == 4 || cislo == '4'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01110101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01110101;
  }
  if(cislo == 5 || cislo == '5'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11010111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11010111;
  }
  if(cislo == 6 || cislo == '6'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11011111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11011111;
  }
  if(cislo == 7 || cislo == '7'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10100101);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10100101;
  }
  if(cislo == 8 || cislo == '8'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11111111;
  }
  if(cislo == 9 || cislo == '9'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11110111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11110111;
  }
  if(cislo == 0 || cislo == '0'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11101111);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11101111;
  }
}

  if(tecka == 0 || tecka == '0'){
    if(cislo == '-'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00010000);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00010000;
  }
    if(cislo == '_'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000010);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00000010;
  }
    if(cislo == 'A'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111100);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11111100;
  }
  if(cislo == 'b'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01011110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01011110;
  }
  if(cislo == 'C'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11001010);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11001010;
  }
  if(cislo == 'c'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00011010);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00011010;
  }
  if(cislo == 'd'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00111110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00111110;
  }
  if(cislo == 'E'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11011010);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11011010;
  }
  if(cislo == 'F'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11011000);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11011000;
  }
  if(cislo == 'H'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01111100);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01111100;
  }
  if(cislo == 'h'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01011100);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01011100;
  }
  if(cislo == 'I'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00100100);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00100100;
  }
  if(cislo == 'i'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000100);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00000100;
  }
  if(cislo == 'L'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01001010);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01001010;
  }
  if(cislo == 'n'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00011100);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00011100;
  }
  if(cislo == 'O'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11101110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11101110;
  }
  if(cislo == 'o'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00011110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00011110;
  }
  if(cislo == 'P'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111000);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11111000;
  }
  if(cislo == 'S'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11010110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11010110;
  }
  if(cislo == 'U'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01101110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01101110;
  }
  if(cislo == 'u'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00001110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00001110;
  }
  if(cislo == 'Y'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01110100);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01110100;
  }
  if(cislo == 'Z'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10111010);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10111010;
  }
  if(cislo == 1 || cislo == '1'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00100100);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B00100100;
  }
  if(cislo == 2 || cislo == '2'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10111010);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10111010;
  }
  if(cislo == 3 || cislo == '3'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10110110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10110110;
  }
  if(cislo == 4 || cislo == '4'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B01110100);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B01110100;
  }
  if(cislo == 5 || cislo == '5'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11010110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11010110;
  }
  if(cislo == 6 || cislo == '6'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11011110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11011110;
  }
  if(cislo == 7 || cislo == '7'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B10100100);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B10100100;
  }
  if(cislo == 8 || cislo == '8'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11111110;
  }
  if(cislo == 9 || cislo == '9'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11110110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11110110;
  }
  if(cislo == 0 || cislo == '0'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11101110);
    digitalWrite(_latchPin,HIGH);
    _ZNAK = B11101110;
  }
}
}
}
//>-------------------------------------------------------------------------------------------------------------
//>-------------------------------------------------------------------------------------------------------------

if(_viditelnost == false){
//-------------------------------------------------------------------

if(_type == '+'){
    if(cislo == '.'){
    _ZNAK = B11111110;
  }
  if(cislo == '#' || cislo == ' '){
    _ZNAK = B11111111;
   }
  if(tecka == 1 || tecka == '1'){
    if(cislo == '_'){
    _ZNAK = B11111100;
  }
    if(cislo == '-'){
    _ZNAK = B11101110;
  }
    if(cislo == 'A'){
    _ZNAK = B00000010;
  }
  if(cislo == 'b'){
    _ZNAK = B10100000;
  }
  if(cislo == 'C'){
    _ZNAK = B00110100;
  }
  if(cislo == 'c'){
    _ZNAK = B11100100;
  }
  if(cislo == 'd'){
    _ZNAK = B11000000;
  }
  if(cislo == 'E'){
    _ZNAK = B00100100;
  }
  if(cislo == 'F'){
    _ZNAK = B00100110;
  }
  if(cislo == 'H'){
    _ZNAK = B10000010;
  }
  if(cislo == 'h'){
    _ZNAK = B10100010;
  }
  if(cislo == 'I'){
    _ZNAK = B11011010;
  }
  if(cislo == 'i'){
    _ZNAK = B11111010;
  }
  if(cislo == 'L'){
    _ZNAK = B10110100;
  }
  if(cislo == 'n'){
    _ZNAK = B11100010;
  }
  if(cislo == 'O'){
    _ZNAK = B00010000;
  }
  if(cislo == 'o'){
    _ZNAK = B11100000;
  }
  if(cislo == 'P'){
    _ZNAK = B00000110;
  }
  if(cislo == 'S'){
    _ZNAK = B00101000;
  }
  if(cislo == 'U'){
    _ZNAK = B10010000;
  }
  if(cislo == 'u'){
    _ZNAK = B11110000;
  }
  if(cislo == 'Y'){
    _ZNAK = B10001010;
  }
  if(cislo == 'Z'){
    _ZNAK = B01000100;
  }

  if(cislo == 1 || cislo == '1'){
    _ZNAK = B11011010;
  }
  if(cislo == 2 || cislo == '2'){
    _ZNAK = B01000100;
  }
  if(cislo == 3 || cislo == '3'){
    _ZNAK = B01001000;
  }
  if(cislo == 4 || cislo == '4'){
    _ZNAK = B10001010;
  }
  if(cislo == 5 || cislo == '5'){
    _ZNAK = B00101000;
  }
  if(cislo == 6 || cislo == '6'){
    _ZNAK = B00100000;
  }
  if(cislo == 7 || cislo == '7'){
    _ZNAK = B01011010;
  }
  if(cislo == 8 || cislo == '8'){
    _ZNAK = B00000000;
  }
  if(cislo == 9 || cislo == '9'){
    _ZNAK = B00001000;
  }
  if(cislo == 0 || cislo == '0'){
    _ZNAK = B00010000;
  }
}

  if(tecka == 0 || tecka == '0'){
    if(cislo == '-'){
    _ZNAK = B11101111;
  }
    if(cislo == '_'){
    _ZNAK = B11111101;
  }
    if(cislo == 'A'){
    _ZNAK = B00000011;
  }
  if(cislo == 'b'){
    _ZNAK = B10100001;
  }
  if(cislo == 'C'){
    _ZNAK = B00110101;
  }
  if(cislo == 'c'){
    _ZNAK = B11100101;
  }
  if(cislo == 'd'){
    _ZNAK = B11000001;
  }
  if(cislo == 'E'){
    _ZNAK = B00100101;
  }
  if(cislo == 'F'){
    _ZNAK = B00100111;
  }
  if(cislo == 'H'){
    _ZNAK = B10000011;
  }
  if(cislo == 'h'){
    _ZNAK = B10100011;
  }
  if(cislo == 'I'){
    _ZNAK = B11011011;
  }
  if(cislo == 'i'){
    _ZNAK = B11111011;
  }
  if(cislo == 'L'){
    _ZNAK = B10110101;
  }
  if(cislo == 'n'){
    _ZNAK = B11100011;
  }
  if(cislo == 'O'){
    _ZNAK = B00010001;
  }
  if(cislo == 'o'){
    _ZNAK = B11100001;
  }
  if(cislo == 'P'){
    _ZNAK = B00000111;
  }
  if(cislo == 'S'){
    _ZNAK = B00101001;
  }
  if(cislo == 'U'){
    _ZNAK = B10010001;
  }
  if(cislo == 'u'){
    _ZNAK = B11110001;
  }
  if(cislo == 'Y'){
    _ZNAK = B10001011;
  }
  if(cislo == 'Z'){
    _ZNAK = B01000101;
  }
  if(cislo == 1 || cislo == '1'){
    _ZNAK = B11011011;
  }
  if(cislo == 2 || cislo == '2'){
    _ZNAK = B01000101;
  }
  if(cislo == 3 || cislo == '3'){
    _ZNAK = B01001001;
  }
  if(cislo == 4 || cislo == '4'){
    _ZNAK = B10001011;
  }
  if(cislo == 5 || cislo == '5'){
    _ZNAK = B00101001;
  }
  if(cislo == 6 || cislo == '6'){
    _ZNAK = B00100001;
  }
  if(cislo == 7 || cislo == '7'){
    _ZNAK = B01011011;
  }
  if(cislo == 8 || cislo == '8'){
    _ZNAK = B00000001;
  }
  if(cislo == 9 || cislo == '9'){
    _ZNAK = B00001001;
  }
  if(cislo == 0 || cislo == '0'){
    _ZNAK = B00010001;
  }
}
}
if(_type == '-'){
    if(cislo == '.'){
    _ZNAK = B00000001;
  }
  if(cislo == '#' || cislo == ' '){
    _ZNAK = B00000000;
   }
  if(tecka == 1 || tecka == '1'){
    if(cislo == '-'){
    _ZNAK = B00010001;
  }
    if(cislo == '_'){
    _ZNAK = B00000011;
  }
    if(cislo == 'A'){
    _ZNAK = B11111101;
  }
  if(cislo == 'b'){
    _ZNAK = B01011111;
  }
  if(cislo == 'C'){
    _ZNAK = B11001011;
  }
  if(cislo == 'c'){
    _ZNAK = B00011011;
  }
  if(cislo == 'd'){
    _ZNAK = B00111111;
  }
  if(cislo == 'E'){
    _ZNAK = B11011011;
  }
  if(cislo == 'F'){
    _ZNAK = B11011001;
  }
  if(cislo == 'H'){
    _ZNAK = B01111101;
  }
  if(cislo == 'h'){
    _ZNAK = B01011101;
  }
  if(cislo == 'I'){
    _ZNAK = B00100101;
  }
  if(cislo == 'i'){
    _ZNAK = B00000101;
  }
  if(cislo == 'L'){
    _ZNAK = B01001011;
  }
  if(cislo == 'n'){
    _ZNAK = B00011101;
  }
  if(cislo == 'O'){
    _ZNAK = B11101111;
  }
  if(cislo == 'o'){
    _ZNAK = B00011111;
  }
  if(cislo == 'P'){
    _ZNAK = B11111001;
  }
  if(cislo == 'S'){
    _ZNAK = B11010111;
  }
  if(cislo == 'U'){
    _ZNAK = B01101111;
  }
  if(cislo == 'u'){
    _ZNAK = B00001111;
  }
  if(cislo == 'Y'){
    _ZNAK = B01110101;
  }
  if(cislo == 'Z'){
    _ZNAK = B10111011;
  }
  if(cislo == 1 || cislo == '1'){
    _ZNAK = B00100101;
  }
  if(cislo == 2 || cislo == '2'){
    _ZNAK = B10111011;
  }
  if(cislo == 3 || cislo == '3'){
    _ZNAK = B10110111;
  }
  if(cislo == 4 || cislo == '4'){
    _ZNAK = B01110101;
  }
  if(cislo == 5 || cislo == '5'){
    _ZNAK = B11010111;
  }
  if(cislo == 6 || cislo == '6'){
    _ZNAK = B11011111;
  }
  if(cislo == 7 || cislo == '7'){
    _ZNAK = B10100101;
  }
  if(cislo == 8 || cislo == '8'){
    _ZNAK = B11111111;
  }
  if(cislo == 9 || cislo == '9'){
    _ZNAK = B11110111;
  }
  if(cislo == 0 || cislo == '0'){
    _ZNAK = B11101111;
  }
}

  if(tecka == 0 || tecka == '0'){
    if(cislo == '-'){
    _ZNAK = B00010000;
  }
    if(cislo == '_'){
    _ZNAK = B00000010;
  }
    if(cislo == 'A'){
    _ZNAK = B11111100;
  }
  if(cislo == 'b'){
    _ZNAK = B01011110;
  }
  if(cislo == 'C'){
    _ZNAK = B11001010;
  }
  if(cislo == 'c'){
    _ZNAK = B00011010;
  }
  if(cislo == 'd'){
    _ZNAK = B00111110;
  }
  if(cislo == 'E'){
    _ZNAK = B11011010;
  }
  if(cislo == 'F'){
    _ZNAK = B11011000;
  }
  if(cislo == 'H'){
    _ZNAK = B01111100;
  }
  if(cislo == 'h'){
    _ZNAK = B01011100;
  }
  if(cislo == 'I'){
    _ZNAK = B00100100;
  }
  if(cislo == 'i'){
    _ZNAK = B00000100;
  }
  if(cislo == 'L'){
    _ZNAK = B01001010;
  }
  if(cislo == 'n'){
    _ZNAK = B00011100;
  }
  if(cislo == 'O'){
    _ZNAK = B11101110;
  }
  if(cislo == 'o'){
    _ZNAK = B00011110;
  }
  if(cislo == 'P'){
    _ZNAK = B11111000;
  }
  if(cislo == 'S'){
    _ZNAK = B11010110;
  }
  if(cislo == 'U'){
    _ZNAK = B01101110;
  }
  if(cislo == 'u'){
    _ZNAK = B00001110;
  }
  if(cislo == 'Y'){
    _ZNAK = B01110100;
  }
  if(cislo == 'Z'){
    _ZNAK = B10111010;
  }
  if(cislo == 1 || cislo == '1'){
    _ZNAK = B00100100;
  }
  if(cislo == 2 || cislo == '2'){
    _ZNAK = B10111010;
  }
  if(cislo == 3 || cislo == '3'){
    _ZNAK = B10110110;
  }
  if(cislo == 4 || cislo == '4'){
    _ZNAK = B01110100;
  }
  if(cislo == 5 || cislo == '5'){
    _ZNAK = B11010110;
  }
  if(cislo == 6 || cislo == '6'){
    _ZNAK = B11011110;
  }
  if(cislo == 7 || cislo == '7'){
    _ZNAK = B10100100;
  }
  if(cislo == 8 || cislo == '8'){
    _ZNAK = B11111110;
  }
  if(cislo == 9 || cislo == '9'){
    _ZNAK = B11110110;
  }
  if(cislo == 0 || cislo == '0'){
    _ZNAK = B11101110;
  }//----------------------------------------------------------------------------------------------------------------------------------------
}//------------------------------------------------------------------------------------------------------------------------------------------
}//------------------------------------------------------------------------------------------------------------------------------------------
}//------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------
}//------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------
//>------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------

void SegmentDisplay_74HC595::write(int cislo, byte tecka, byte jas){
  if(_zapojeni == true){
    write(cislo,tecka);
    setBrightness(jas);
  }
}

void SegmentDisplay_74HC595::clear(){
  if(_type == '+'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B11111111);
    digitalWrite(_latchPin,HIGH);
  }
  if(_type == '-'){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,B00000000);
    digitalWrite(_latchPin,HIGH);
  }
    _ZNAK = 0;
}

void SegmentDisplay_74HC595::createChar(byte znak,byte adresa){
  adresa = constrain(adresa,0,9);
  mujZnak[adresa] = znak;
}
void SegmentDisplay_74HC595::writeMyChar(byte MujZnak,byte mode){
if(mode == 1){
MujZnak = constrain(MujZnak,0,9);
if(_viditelnost == true){
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,mujZnak[MujZnak]);
    digitalWrite(_latchPin,HIGH);
  _ZNAK = MujZnak;
}

if(_viditelnost == false){
_ZNAK = mujZnak[MujZnak];
}
}
if(mode == 2){
  digitalWrite(_latchPin,LOW);
  shiftOut(_dataPin,_clockPin,MSBFIRST,MujZnak);
  digitalWrite(_latchPin,HIGH);
  _ZNAK = MujZnak;
}
}
void SegmentDisplay_74HC595::noDisplay(){
    _viditelnost = false;
    if(_type == '+'){
        digitalWrite(_latchPin,LOW);
        shiftOut(_dataPin,_clockPin,MSBFIRST,B11111111);
        digitalWrite(_latchPin,HIGH);
    }
    if(_type == '-'){
        digitalWrite(_latchPin,LOW);
        shiftOut(_dataPin,_clockPin,MSBFIRST,B00000000);
        digitalWrite(_latchPin,HIGH);
    }
}
void SegmentDisplay_74HC595::display(){
    _viditelnost = true;
    digitalWrite(_latchPin,LOW);
    shiftOut(_dataPin,_clockPin,MSBFIRST,_ZNAK);
    digitalWrite(_latchPin,HIGH);
}

void SegmentDisplay_74HC595::print(String text, byte tecka, unsigned int interval){
  byte slovo[(text.length()+1)];
  text.getBytes(slovo,sizeof(slovo));
  for(unsigned int i = 0; i < sizeof(slovo)-1; i++){
    write(char(slovo[i]),tecka);
    delay(interval);
  }
}

byte SegmentDisplay_74HC595::getMyChar(byte adresa){return mujZnak[adresa];}

void SegmentDisplay_74HC595::setBrightness(byte jas){if(_zapojeni == true) analogWrite(_anoda,jas);}