#include "Arduino.h"
#ifndef SegmentDisplay_74HC595_h
#define SegmentDisplay_74HC595_h

class SegmentDisplay_74HC595{
    public:
    SegmentDisplay_74HC595();
    void begin(byte Clock, byte data, byte latch, char dTyp);
    void begin(byte anode, byte Clock, byte data, byte latch, char dTyp);
    void write(int cislo,byte tecka);
    void write(int cislo,byte tecka,byte jas);
    void clear();
    void createChar(byte znak, byte adresa);
    void writeMyChar(byte MujZnak,byte mode);
    byte getMyChar(byte adresa);
    void noDisplay();
    void display();
    void print(String text, byte tecka, unsigned int interval);
    void setBrightness(byte jas);
    #define TYPE_ANODE '+'
    #define TYPE_CATODE '-'
    #define SAVED 1
    #define NOT_SAVED 2
    private:
    int _latchPin;
    int _clockPin;
    int _dataPin;
    byte mujZnak[10];
    byte _ZNAK;
    boolean _viditelnost = true;
    char _type;
    bool _zapojeni;
    byte _anoda;
};

#endif